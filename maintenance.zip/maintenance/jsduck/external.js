/**
 * Source: <https://api.jquery.com/>
 * @class jQuery
 */

/**
 * Source: <https://api.jquery.com/jQuery.ajax/>
 * @method ajax
 * @static
 * @return {jqXHR}
 */

/**
 * Source: <https://api.jquery.com/Types/#Event>
 * @class jQuery.Event
 */

/**
 * Source: <https://api.jquery.com/jQuery.Callbacks/>
 * @class jQuery.Callbacks
 */

/**
 * Source: <https://api.jquery.com/Types/#Promise>
 * @class jQuery.Promise
 */

/**
 * Source: <https://api.jquery.com/jQuery.Deferred/>
 * @class jQuery.Deferred
 * @mixins jQuery.Promise
 */

/**
 * Source: <https://api.jquery.com/Types/#jqXHR>
 * @class jQuery.jqXHR
 * @alternateClassName jqXHR
 */

/**
 * Source: <http://api.qunitjs.com/>
 * @class QUnit
 */
