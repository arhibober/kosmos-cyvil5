-- field is deprecated and no longer updated as of 1.25
ALTER TABLE /*_*/page DROP COLUMN page_counter;
