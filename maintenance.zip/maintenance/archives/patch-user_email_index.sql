CREATE INDEX /*i*/user_email ON /*_*/user (user_email(50));
