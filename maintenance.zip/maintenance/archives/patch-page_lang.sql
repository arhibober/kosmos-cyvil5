ALTER TABLE /*$wgDBprefix*/page
  ADD page_lang varbinary(35) DEFAULT NULL;
