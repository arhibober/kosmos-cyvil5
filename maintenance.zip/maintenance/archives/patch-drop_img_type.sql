-- img_type is no longer used, delete it

ALTER TABLE /*$wgDBprefix*/image DROP COLUMN img_type;
