-- Andrew Garrett, 2009-01
CREATE TABLE /*_*/valid_tag (
	vt_tag varchar(255) NOT NULL PRIMARY KEY
) /*$wgDBTableOptions*/;
