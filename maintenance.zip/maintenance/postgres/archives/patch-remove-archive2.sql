DROP VIEW archive;
ALTER TABLE archive2 RENAME TO archive;
ALTER TABLE archive ADD ar_len INTEGER;
