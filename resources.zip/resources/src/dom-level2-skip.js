/*!
 * Skip function for dom-level2-shim module.
 *
 * Tests for window.Node because that's the only thing that this shim is adding.
 */
return !!window.Node;
