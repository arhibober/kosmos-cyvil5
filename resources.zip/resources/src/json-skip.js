/*!
 * Skip function for json2.js.
 */
return !!( window.JSON && JSON.stringify && JSON.parse );
