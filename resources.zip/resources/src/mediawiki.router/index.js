var Router = require( 'oojs-router' );
module.exports = new Router();
