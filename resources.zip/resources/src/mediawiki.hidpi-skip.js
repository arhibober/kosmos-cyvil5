/*!
 * Skip function for mediawiki.hdpi.js.
 */
return 'srcset' in new Image();
