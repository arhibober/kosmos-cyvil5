/*!
 * JavaScript for Special:UserRights
 */
( function () {
	var convertmessagebox = require( 'mediawiki.notification.convertmessagebox' );
	// Replace successbox with notifications
	convertmessagebox();
}() );
