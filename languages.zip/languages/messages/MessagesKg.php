<?php
/** Kongo (Kongo)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = [
	NS_TALK             => 'Disolo',
	NS_USER             => 'Kisadi',
	NS_USER_TALK        => 'Disolo_kisadi',
	NS_PROJECT_TALK     => 'Disolo_$1',
	NS_FILE             => 'Fisye',
	NS_FILE_TALK        => 'Disolo_fisye',
	NS_HELP             => 'Lusadisu',
	NS_HELP_TALK        => 'Disolo_lusadisu',
	NS_CATEGORY         => 'Kalasi',
	NS_CATEGORY_TALK    => 'Disolo_kalasi',
];

