<?php
/** Batak Toba (Batak Toba)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Batak Toba (Latin)
 */

$fallback = 'bbc-latn';
