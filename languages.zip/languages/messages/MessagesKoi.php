<?php
/** Komi-Permyak (Перем Коми)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Enye Lav
 * @author Yufereff
 */

$fallback = 'ru';

