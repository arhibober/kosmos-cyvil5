<?php
/** Bambara (bamanankan)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = [];

