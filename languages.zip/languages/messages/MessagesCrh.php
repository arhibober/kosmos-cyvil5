<?php
/** Crimean Turkish (Qırımtatarca)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'crh-latn';

$linkTrail = '/^([a-zâçğıñöşüа-яёʺʹ“»]+)(.*)$/sDu';
