<?php
/** Nederlands (informeel)‎ (Nederlands (informeel)‎)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author HanV
 * @author MarkvA
 * @author Siebrand
 * @author Tedjuh10
 */

$fallback = 'nl';

