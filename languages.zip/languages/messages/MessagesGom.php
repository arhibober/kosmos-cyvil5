<?php
/** Goan Konkani (गोंयची कोंकणी / Gõychi Konknni)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'gom-deva';
