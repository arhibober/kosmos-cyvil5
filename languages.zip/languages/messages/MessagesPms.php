<?php
/** Piedmontese (Piemontèis)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Borichèt
 * @author Bèrto 'd Sèra
 * @author Dragonòt
 * @author Geitost
 * @author Kaganer
 * @author MaxSem
 * @author SabineCretella
 * @author Teak
 * @author The Evil IP address
 * @author Ævar Arnfjörð Bjarmason <avarab@gmail.com>, Jens Frank
 * @author לערי ריינהארט
 */

$fallback = 'it';

$namespaceNames = [
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Special',
	NS_TALK             => 'Discussion',
	NS_USER             => 'Utent',
	NS_USER_TALK        => 'Ciaciarade',
	NS_PROJECT_TALK     => 'Discussion_ant_sla_$1',
	NS_FILE             => 'Figura',
	NS_FILE_TALK        => 'Discussion_dla_figura',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Discussion_dla_MediaWiki',
	NS_TEMPLATE         => 'Stamp',
	NS_TEMPLATE_TALK    => 'Discussion_dlë_stamp',
	NS_HELP             => 'Agiut',
	NS_HELP_TALK        => 'Discussion_ant_sl\'agiut',
	NS_CATEGORY         => 'Categorìa',
	NS_CATEGORY_TALK    => 'Discussion_ant_sla_categorìa',
];

