<?php
/** Chavacano de Zamboanga (Chavacano de Zamboanga)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = "es";

