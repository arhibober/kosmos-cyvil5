<?php
/** Romagnol (Rumagnôl)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Reedy
 * @author Sentruper
 */

$fallback = 'it';

