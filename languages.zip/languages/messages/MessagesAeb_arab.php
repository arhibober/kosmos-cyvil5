<?php
/** Tunisian Spoken Arabic (Arabic script) (تونسي)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ar';

$rtl = true;
