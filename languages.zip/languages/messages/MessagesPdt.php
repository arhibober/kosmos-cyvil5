<?php
/** Plautdietsch (Plautdietsch)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Geitost
 * @author Murma174
 * @author Purodha
 * @author Shirayuki
 * @author Slomox
 * @author Wikipeeta
 */

$fallback = 'de';

