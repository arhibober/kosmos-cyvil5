<?php

class TestAutoloadedSerializedClass {
}
