<?php

$result = [ 'xmp-exif' =>
	[
		'DigitalZoomRatio' => '0/10',
	]
];
