<?php

$result = [];
