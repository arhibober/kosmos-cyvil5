<?php
$result = [];
