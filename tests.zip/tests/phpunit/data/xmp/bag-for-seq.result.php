<?php

$result = [
	'xmp-general' => [
		'Artist' => [
			'_type' => 'ul',
			0 => 'The author',
		]
	]
];
