<?php

$result = [ 'xmp-exif' =>
	[
		'FNumber' => '28/10',
	]
];
