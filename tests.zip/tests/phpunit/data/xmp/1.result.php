<?php

$result = [ 'xmp-exif' =>
	[
		'DigitalZoomRatio' => '0/10',
		'Flash' => '9'
	]
];
