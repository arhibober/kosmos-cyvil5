<?php

$result = [
	'xmp-exif' =>
		[
			'DigitalZoomRatio' => '0/10',
		],
	'xmp-general' =>
		[
			'Label' => '􊯍'
		],
];
