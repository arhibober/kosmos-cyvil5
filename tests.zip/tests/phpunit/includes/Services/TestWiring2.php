<?php
/**
 * Test file for testing ServiceContainer::loadWiringFiles
 */

return [
	'Bar' => function() {
		return 'Bar!';
	},
];
